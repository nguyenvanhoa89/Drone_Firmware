#!/bin/sh

# Copyright (C) 2006-2016 Intel Corporation. All rights reserved.
# This script installs Intel(R) Software Development Products.

$(dirname $0)/install.sh --gui-mode $@
